import UIKit

func function1() {
    print("function")
}
function1()


func function2(param: [Int]) {
    for index in param {
        print("\(index)")
    }
}
function2(param: [1, 5, 11])


func twoParametersReturningFunction1() -> [String] {
    ["1" , "2", "3", "4"]
}
let object1 = twoParametersReturningFunction1()
print(object1[2])


func returningMultipleValue() -> (returnedParam1: String, returnedParam2: String) {
    (returnedParam1: "Ahmet", returnedParam2: "Ali")
}
let object2 = returningMultipleValue()
print(object2.returnedParam1)


func paramaterLabel(for string: String)  {
    print("Hey \(string)")
}
paramaterLabel(for: "Ahmet")


func defaultParam(_ first: String, second: Bool = true) {
    if second == true {
        print("\(first)")
    }else {
        print("\(second)")
    }
}
defaultParam("Veli")
defaultParam("Vehbi", second: false)


func variadicFunction(params: Int...) { // params is taking different parameters with Variadic functions
    for param in params {
        print("\(param)")
    }
}
variadicFunction(params: 4, 6, 9, 12, 5)


func inoutFunction(param: inout Int) {
    param = param * 8
}
var mutableParam = 8
inoutFunction(param: &mutableParam)
